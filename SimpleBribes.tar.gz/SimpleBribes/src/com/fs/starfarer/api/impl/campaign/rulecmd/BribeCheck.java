package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.util.Misc;
import java.util.List;
import java.util.Map;


 public class BribeCheck
   extends BaseCommandPlugin
 {
  public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
     if (dialog == null) return false;
     CampaignFleetAPI otherFleet = (CampaignFleetAPI) (dialog.getInteractionTarget());
     float credits = Global.getSector().getPlayerFleet().getCargo().getCredits().get();
     float bribe = (otherFleet.getFleetPoints() + Global.getSector().getPlayerFleet().getFleetPoints())*543;
     ((MemoryAPI)memoryMap.get("local")).set("$Bribe_value", Integer.valueOf((int)bribe), 0.0F);
     ((MemoryAPI)memoryMap.get("local")).set("$Bribe_DGS", Misc.getWithDGS(bribe), 0.0F);
    return (credits >= bribe);
  }
 }
