import os
home = os.getcwd()
SimpleRules = open(home+"/data/campaign/rules.csv","w")
wlist = open(home + "/pySettings.monky","r").readlines()
comments = []
for f in range(len(wlist)-1):
    wlist[f] = wlist[f].rstrip("\n")
for f in wlist:
    if(f.startswith("#")):
        comments.append(f)
for f in comments:
    wlist.remove(f)

wcheck = [True]*len(wlist)
SimpleRules.write("id,trigger,conditions,script,text,options,notes\n")
SimpleRules.write('BribePay,DialogOptionSelected,$option == payBribe,"AddRemoveCommodity credits -$Bribe_value true\n$entity.Bribed = true 30\nMakeOtherFleetNonHostile $Bribe_Value true 30\nAddText ""The connection is cut before you have a chance to respond.""\nShowDefaultVisual\n$entity.ignorePlayerCommRequests = true 1\nEndConversation",""Now get lost and don\'t ever cross me again"",cutCommLink:Cut the comm link,\n')
mods = os.listdir(os.path.dirname(home))
mods.remove("SimpleBribes")
parent = home.split("/")
parent.remove(parent[-1])
parent = "/".join(parent)
print(parent)
#patching vanilla
print("patching vanilla")
vanilla = parent.split("/")
vanilla.remove(vanilla[-1])
vanilla = "/".join(vanilla)
file = open(vanilla+"/data/campaign/rules.csv","r").read()
print(vanilla+"/data/campaign/rules.csv")
level = 0
rule = ""
quoted = False
rulist = []
tempwcheck = [True]*len(wlist)
while level < len(file):
    while level < len(file):
        rule += file[level]
        if(file[level]=='"'):
            quoted = not quoted
        elif(file[level]==',' and not quoted):
            rule = rule[0:-1]
            rulist.append(rule)
            rule = ""
        level+=1
        if(len(rulist)>=6):
            break
    if(level >= len(file)):
        break
    for fac in wlist :
        if(wcheck[wlist.index(fac)] and fac in rulist[2].lower() and ("$entity.weakerThanPlayerButHolding" in rulist[2] or "$entity.relativeStrength >= 0" in rulist[2]) and "$entity.isHostile" in rulist[2]):
            rulist[0] += "Bribe"
            rulist[2] = '"' +rulist[2].replace('"','') + '\nBribeCheck score:5\n!$Bribed"'
            rulist[5] = '"payBribe:Bribe the enemy $personRank for $Bribe_DGS credits\n'+rulist[5].replace('"','')+ '",'
            SimpleRules.write(",".join(rulist))
            print("patched "+fac)
            tempwcheck[wlist.index(fac)] = False
    rulist = []
wcheck = tempwcheck
#patching mods
for mod in mods :
    try:
        modRule = open(parent+"/"+mod+"/data/campaign/rules.csv","r")
        print(mod + " is a valid mod")
        file = modRule.read()
        level = 0
        rule = ""
        quoted = False
        rulist = []
        while level < len(file):
            while level < len(file):
                rule += file[level]
                if(file[level]=='"'):
                    quoted = not quoted
                elif(file[level]==',' and not quoted):
                    rule = rule[0:-1]
                    rulist.append(rule)
                    rule = ""
                level+=1
                if(len(rulist)>=6):
                    break
            if(level >= len(file)):
                break
            for fac in wlist :
                if(wcheck[wlist.index(fac)] and fac in rulist[2].lower() and ("$entity.weakerThanPlayerButHolding" in rulist[2] or "$entity.relativeStrength >= 0" in rulist[2]) and "$entity.isHostile" in rulist[2]):
                    rulist[0] += "Bribe"
                    rulist[2] = '"' +rulist[2].replace('"','') + '\nBribeCheck score:5\n!$Bribed"'
                    rulist[5] = '"payBribe:Bribe the enemy $personRank for $Bribe_DGS credits\n'+rulist[5].replace('"','')+ '",'
                    SimpleRules.write(",".join(rulist))
                    print("patched "+fac)
                    tempwcheck[wlist.index(fac)] = False
            rulist = []
        wcheck = tempwcheck
    except IOError as e:
       print(mod + " isn't a valid mod")
#patching factions using default greetings
for fac in wlist :
    if(wcheck[wlist.index(fac)]):
        SimpleRules.write('\ngreeting'+fac+'HostileWeakerDefiantBribe,OpenCommLink,"$faction.id == '+fac+'\n$entity.isHostile\nBribeCheck score:5\n!$Bribed\n$entity.relativeStrength < 0\n$entity.weakerThanPlayerButHolding",$ignorePlayerCommRequests = true 1,"The enemy $personRank looks grim but defiant. ""We will fight you to the last,"" $heOrShe says.\nOR\n""Damn, we\'re in a tight spot."" $PersonRank $personName suddenly notices the line is open and shuts it off.","payBribe:Bribe the enemy $personRank for $Bribe_DGS credits\ncutCommLink:Cut the comm link",')
        SimpleRules.write('\ngreeting'+fac+'HostileStrongerBribe,OpenCommLink,"$faction.id == '+fac+'\n$entity.isHostile\nBribeCheck score:5\n!$Bribed\n$entity.relativeStrength >= 0",$ignorePlayerCommRequests = true 1,"""Surrender yourself and your goods or you\'ll be taking a very long walk out the airlock once I\'ve claimed your ship.""",,')
        print("patched extra "+ fac)
